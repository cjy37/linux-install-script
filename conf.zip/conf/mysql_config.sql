﻿use mysql;
update user set password=PASSWORD('Ht141421') where user='root';
update user set host='%' where user='root' and host='localhost';
delete from user where password='';
grant all privileges on *.* to root@'%' identified by "Ht141421";
flush privileges;
